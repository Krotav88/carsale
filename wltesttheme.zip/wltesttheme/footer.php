<?php
/**
 * Footer
 *
 * @package WordPress
 * @subpackage WL Test Theme
 * @since WL Test Theme 0.1
 */
?>

<?php wp_footer(); ?>
</body>
</html>